HTTP methods in React refer to the actions you perform to communicate with backend servers or APIs, primarily through HTTP requests.

 In React, these HTTP requests are most commonly made using either the native Fetch API or the Axios library.

 The typical HTTP methods used are:

- **GET**: Retrieves data from a server. In React, you can use `fetch(url)` or `axios.get(url)` inside lifecycle hooks like `useEffect` or lifecycle methods in class components.
- **POST**: Sends data to a server to create a new resource. Use `fetch(url, { method: 'POST', body: ... })` or `axios.post(url, data)`.
- **PUT**: Updates an existing resource on the server. Use `fetch(url, { method: 'PUT', body: ... })` or `axios.put(url, data)`.
- **DELETE**: Removes a resource from the server. Use `fetch(url, { method: 'DELETE' })` or `axios.delete(url)`.

React itself does not define these methods but provides ways (hooks and component lifecycles) to integrate the HTTP requests into the UI logic. Fetch is a built-in browser API providing basic HTTP features, while Axios is a popular third-party library that adds convenience features like automatic JSON parsing, request cancellation, and interceptors.

In practice, React developers use these HTTP methods to fetch and manipulate data dynamically, typically within functional components using hooks like `useEffect` or in class components with lifecycle methods such as `componentDidMount`.

********************************************************************
import React, { useState, useEffect } from 'react';

function FetchExample() {
  const [data, setData] = useState([]);
  const [input, setInput] = useState('');
  const [editId, setEditId] = useState(null);

  // GET Request
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(res => res.json())
      .then(json => setData(json.slice(0, 5))) // limit to 5 items for demo
      .catch(err => console.error('GET Error:', err));
  }, []);

  // POST Request
  const addItem = () => {
    fetch('https://jsonplaceholder.typicode.com/posts', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ title: input, body: 'Sample body', userId: 1 }),
    })
      .then(res => res.json())
      .then(newItem => setData([newItem, ...data]))
      .catch(err => console.error('POST Error:', err));
  };

  // PUT Request
  const updateItem = id => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ title: input, body: 'Updated body', userId: 1 }),
    })
      .then(res => res.json())
      .then(updatedItem => {
        setData(data.map(item => (item.id === id ? updatedItem : item)));
        setEditId(null);
        setInput('');
      })
      .catch(err => console.error('PUT Error:', err));
  };

  // DELETE Request
  const deleteItem = id => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      method: 'DELETE',
    })
      .then(() => setData(data.filter(item => item.id !== id)))
      .catch(err => console.error('DELETE Error:', err));
  };

  return (
    <div>
      <h2>Fetch API CRUD Example</h2>
      <input
        type="text"
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Enter title"
      />
      {editId ? (
        <button onClick={() => updateItem(editId)}>Update</button>
      ) : (
        <button onClick={addItem}>Add</button>
      )}
      <ul>
        {data.map(post => (
          <li key={post.id}>
            {post.title}
            <button onClick={() => { setEditId(post.id); setInput(post.title); }}>Edit</button>
            <button onClick={() => deleteItem(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default FetchExample;


*******************************************************************
React Example with Axios


import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AxiosExample() {
  const [data, setData] = useState([]);
  const [input, setInput] = useState('');
  const [editId, setEditId] = useState(null);

  // GET Request
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(response => setData(response.data))
      .catch(error => console.error('GET Error:', error));
  }, []);

  // POST Request
  const addItem = () => {
    axios.post('https://jsonplaceholder.typicode.com/posts', {
      title: input,
      body: 'Sample body',
      userId: 1,
    })
      .then(response => setData([response.data, ...data]))
      .catch(error => console.error('POST Error:', error));
  };

  // PUT Request
  const updateItem = id => {
    axios.put(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      title: input,
      body: 'Updated body',
      userId: 1,
    })
      .then(response => {
        setData(data.map(item => (item.id === id ? response.data : item)));
        setEditId(null);
        setInput('');
      })
      .catch(error => console.error('PUT Error:', error));
  };

  // DELETE Request
  const deleteItem = id => {
    axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then(() => setData(data.filter(item => item.id !== id)))
      .catch(error => console.error('DELETE Error:', error));
  };

  return (
    <div>
      <h2>Axios CRUD Example</h2>
      <input
        type="text"
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Enter title"
      />
      {editId ? (
        <button onClick={() => updateItem(editId)}>Update</button>
      ) : (
        <button onClick={addItem}>Add</button>
      )}
      <ul>
        {data.map(post => (
          <li key={post.id}>
            {post.title}
            <button onClick={() => { setEditId(post.id); setInput(post.title); }}>Edit</button>
            <button onClick={() => deleteItem(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AxiosExample;


Notes:
Both examples use JSONPlaceholder (https://jsonplaceholder.typicode.com/) as a mock API.

You can include either component in your React app, e.g., by importing it in App.js.

For Axios, ensure you install it via npm install axios before running.