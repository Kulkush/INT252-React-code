Routing in React enables navigation between different pages or views within a single-page application (SPA).

React Router is the most widely used library to manage routing in React apps.
 
It allows you to set up routes, navigate programmatically, pass data between pages via URL parameters or state, and handle browser history for forward and backward navigation.

***

## Theory: React Routing Concepts

- **Setting up Routing and Routes**: Define different routes corresponding to components/pages your app will display.
- **Navigating to Pages**: Move between routes programmatically or using links.
- **Navigating Back and Forward**: Use browser’s history stack to go back or forward in navigation.
- **Passing Data via Query Params**: Send data in the URL query string for the target page to read.
- **Passing Data Between Pages (State)**: Pass data through navigation state object to avoid exposing in URLs.
- **Fetching Data**: Based on route parameters or query params, components fetch relevant data.

***

## Step-by-Step Routing Example Using React Router (v6+)

### Step 1: Setup React Router

Install React Router:

```bash
npm install react-router-dom
```

***

### Step 2: Basic Router Setup with Routes

```jsx
// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import HomePage from './HomePage';
import AboutPage from './AboutPage';
import ProfilePage from './ProfilePage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        {/* Route with URL Param */}
        <Route path="/profile/:userId" element={<ProfilePage />} />
      </Routes>
    </Router>
  );
}

export default App;
```

***

### Step 3: Navigating Between Pages

```jsx
// HomePage.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

function HomePage() {
  const navigate = useNavigate();

  // Navigation using useNavigate programmatically
  const goToAbout = () => {
    navigate('/about');
  };

  // Navigation with query params
  const goToProfileWithQuery = () => {
    navigate('/profile/123?showDetails=true');
  };

  return (
    <div>
      <h1>Home Page</h1>
      {/* Link component for navigation */}
      <Link to="/about">Go to About</Link><br />
      <button onClick={goToAbout}>Go to About (programmatic)</button><br />
      <button onClick={goToProfileWithQuery}>Go to Profile 123 with Query</button>
    </div>
  );
}

export default HomePage;
```

***

### Step 4: Accessing Route Params, Query Params, and Navigation State

```jsx
// ProfilePage.js
import React from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';

function ProfilePage() {
  const { userId } = useParams(); // URL param
  const location = useLocation(); // Access location object
  const navigate = useNavigate();

  // Parse query params
  const queryParams = new URLSearchParams(location.search);
  const showDetails = queryParams.get('showDetails');

  // Example of navigation state (optional)
  const passedData = location.state?.data;

  return (
    <div>
      <h1>Profile Page for User {userId}</h1>
      {showDetails === 'true' && <p>Showing detailed information</p>}
      {passedData && <p>Data passed via state: {passedData}</p>}

      {/* Navigation buttons */}
      <button onClick={() => navigate(-1)}>Go Back</button>
      <button onClick={() => navigate(1)}>Go Forward</button>
    </div>
  );
}

export default ProfilePage;
```

***

### Step 5: Passing Data Between Pages via State

```jsx
// AboutPage.js
import React from 'react';
import { useNavigate } from 'react-router-dom';

function AboutPage() {
  const navigate = useNavigate();

  const goToProfileWithState = () => {
    navigate('/profile/456', { state: { data: 'Passed via state!' } });
  };

  return (
    <div>
      <h1>About Page</h1>
      <button onClick={goToProfileWithState}>Go to Profile 456 with State</button>
    </div>
  );
}

export default AboutPage;
```

***

### Step 6: Fetching Data Based on Route Params

In `ProfilePage`, you can use JavaScript `useEffect` hook to fetch data based on the `userId` param.

```jsx
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

function ProfilePage() {
  const { userId } = useParams();
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    // Replace with actual API call
    fetch(`https://jsonplaceholder.typicode.com/users/${userId}`)
      .then(res => res.json())
      .then(data => setProfileData(data))
      .catch(err => console.error(err));
  }, [userId]);

  if (!profileData) return <p>Loading...</p>;

  return (
    <div>
      <h1>{profileData.name}'s Profile</h1>
      <p>Email: {profileData.email}</p>
      {/* Other profile details */}
    </div>
  );
}

export default ProfilePage;
```

***

@image.jpg



