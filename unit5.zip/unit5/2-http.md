HTTP methods in React are essential for interacting with backend services or APIs to fetch or modify data. 
React itself doesn't create these methods but provides ways to use them efficiently. The two most common ways to perform HTTP methods in React are using the Fetch API (native to browsers) and Axios (a popular third-party library). 
Below is a step-by-step guide with theory and practical examples for GET, POST, PUT, and DELETE requests using both Fetch and Axios in React.

***

## Theory: Understanding HTTP Methods in React

- **GET**: Retrieve data from a server (e.g., fetching a list of posts).
- **POST**: Send data to the server to create a new resource (e.g., adding a new post).
- **PUT**: Update an existing resource on the server (e.g., editing a post).
- **DELETE**: Remove a resource from the server (e.g., deleting a post).

React components often use these HTTP methods inside lifecycle events or hooks for interaction with APIs, enabling dynamic and interactive user interfaces.

***

## Step-by-Step Examples in React

### Using Fetch API

### Step 1: Setup a React Component

```jsx
import React, { useState, useEffect } from 'react';

function FetchCRUD() {
  const [data, setData] = useState([]);
  const [input, setInput] = useState('');
  const [editId, setEditId] = useState(null);
```

*******************************************************************
Here is a simple React example demonstrating how to perform a GET request to fetch data from an API using the Fetch API inside a functional component with the `useEffect` hook:

```jsx
import React, { useState, useEffect } from 'react';

function FetchDataExample() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Perform GET request to fetch posts
    fetch('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(jsonData => {
        setData(jsonData);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []); // Empty dependency array means this runs once after mounting

  if (loading) return <p>Loading data...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h2>Fetched Posts</h2>
      <ul>
        {data.map(post => (
          <li key={post.id}>
            <strong>{post.title}</strong><br />
            {post.body}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default FetchDataExample;
```

### Explanation:
- `useState` initializes state for `data`, `loading`, and `error`.
- `useEffect` runs once on component mount to perform the fetch call.
- The GET request uses `fetch()` to retrieve 5 posts from a mock API.
- On success, it updates state with fetched data and stops loading.
- On failure, it stores the error and stops loading.
- The UI reflects loading and error states and displays the fetched data in a list.

This example shows a clear, practical way to fetch and display data using a GET request in a React functional component.
*******************************************************************

### Step 2: Perform a GET Request to Fetch Data

```jsx
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(response => response.json())
      .then(json => setData(json))
      .catch(err => console.error('Error fetching data:', err));
  }, []);
```

### Step 3: POST Request to Add Data

```jsx
  const addData = () => {
    fetch('https://jsonplaceholder.typicode.com/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: input, body: 'Example body', userId: 1 }),
    })
      .then(response => response.json())
      .then(newItem => setData([newItem, ...data]))
      .catch(err => console.error('Error adding data:', err));
  };
```

************************************************************************
Here is a React example demonstrating how to perform a POST request to add data using the Fetch API inside a functional component with the `useState` hook for input and `useEffect` to manage side effects if needed:

```jsx
import React, { useState } from 'react';

function PostDataExample() {
  const [title, setTitle] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Perform POST request to add a new post
    fetch('https://jsonplaceholder.typicode.com/posts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        title: title,
        body: 'Example post body',
        userId: 1,
      }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        setResponseData(data);
        setError(null);
        setTitle('');
      })
      .catch((err) => {
        setError(err.message);
        setResponseData(null);
      });
  };

  return (
    <div>
      <h2>Add a New Post</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter post title"
          required
        />
        <button type="submit">Add Post</button>
      </form>

      {responseData && (
        <div>
          <h3>Post Added Successfully:</h3>
          <p>ID: {responseData.id}</p>
          <p>Title: {responseData.title}</p>
        </div>
      )}

      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
    </div>
  );
}

export default PostDataExample;
```

### Explanation:
- User inputs a title, managed by `title` state.
- On form submission, a POST request sends the new post data as JSON.
- If successful, the server response is shown (including the new post ID).
- Errors are caught and displayed to the user.
- The form input clears after successful submission.

This example clearly illustrates adding data through a POST request in React using Fetch.
****************************************************************************


### Step 4: PUT Request to Update Data

```jsx
  const updateData = id => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: input, body: 'Updated body', userId: 1 }),
    })
      .then(response => response.json())
      .then(updatedItem => {
        setData(data.map(item => (item.id === id ? updatedItem : item)));
        setEditId(null);
        setInput('');
      })
      .catch(err => console.error('Error updating data:', err));
  };
```
********************************************************************
Here is a React example demonstrating how to perform a PUT request to update data using the Fetch API inside a functional component. It includes input to update a post title and sends the updated data via PUT:

```jsx
import React, { useState, useEffect } from 'react';

function PutDataExample() {
  const [postId, setPostId] = useState(1);
  const [title, setTitle] = useState('');
  const [updatedData, setUpdatedData] = useState(null);
  const [error, setError] = useState(null);

  // Fetch existing data to prefill input (optional)
  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`)
      .then(res => res.json())
      .then(data => setTitle(data.title))
      .catch(err => console.error('Error fetching post:', err));
  }, [postId]);

  const handleUpdate = (e) => {
    e.preventDefault();

    fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: postId,
        title: title,
        body: 'Updated post body',
        userId: 1,
      }),
    })
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then(data => {
        setUpdatedData(data);
        setError(null);
      })
      .catch(err => {
        setError(err.message);
        setUpdatedData(null);
      });
  };

  return (
    <div>
      <h2>Update Post (PUT Request)</h2>
      <form onSubmit={handleUpdate}>
        <label>
          Post ID to Update:
          <input
            type="number"
            value={postId}
            onChange={e => setPostId(Number(e.target.value))}
            min="1"
            max="100"
          />
        </label>
        <br />
        <label>
          Title:
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            required
          />
        </label>
        <br />
        <button type="submit">Update Post</button>
      </form>

      {updatedData && (
        <div>
          <h3>Post Updated Successfully:</h3>
          <p>ID: {updatedData.id}</p>
          <p>Title: {updatedData.title}</p>
        </div>
      )}

      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
    </div>
  );
}

export default PutDataExample;
```

### Explanation:
- User inputs the post ID and new title.
- Initially, data for the post ID is fetched to prefill the title field.
- On form submission, a PUT request updates the post with new data.
- Response displays updated info; errors are handled gracefully.

This example shows how to update data using PUT in React with a controlled form and Fetch API.
*******************************************************************
### Step 5: DELETE Request to Remove Data

```jsx
  const deleteData = id => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`, { method: 'DELETE' })
      .then(() => setData(data.filter(item => item.id !== id)))
      .catch(err => console.error('Error deleting data:', err));
  };
```

***********************************************************************
Here is a React example demonstrating how to perform a DELETE request to remove data using the Fetch API inside a functional component. The example includes a simple list of posts with a delete button for each item:

```jsx
import React, { useState, useEffect } from 'react';

function DeleteDataExample() {
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState(null);

  // Fetch posts initially
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(res => res.json())
      .then(data => setPosts(data))
      .catch(err => setError(err.message));
  }, []);

  const deletePost = (id) => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      method: 'DELETE',
    })
      .then(response => {
        if (!response.ok) throw new Error('Failed to delete the post');
        // Update UI by removing the deleted post
        setPosts(posts.filter(post => post.id !== id));
        setError(null);
      })
      .catch(err => setError(err.message));
  };

  return (
    <div>
      <h2>Delete Post Example</h2>
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <strong>{post.title}</strong>
            <button onClick={() => deletePost(post.id)} style={{ marginLeft: '10px' }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default DeleteDataExample;
```

### Explanation:
- The component fetches 5 posts initially to display.
- Each post has a Delete button.
- Clicking Delete sends a DELETE request to the server.
- On successful deletion, the UI is updated by filtering the post out of the state.
- Errors during deletion are handled and displayed.

This example shows a practical way to remove data using a DELETE request in React using Fetch.
**************************************************************************

### Step 6: UI for Interaction

```jsx
  return (
    <div>
      <h2>Fetch API CRUD Example</h2>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Enter title"
      />
      {editId ? (
        <button onClick={() => updateData(editId)}>Update</button>
      ) : (
        <button onClick={addData}>Add</button>
      )}
      <ul>
        {data.map(post => (
          <li key={post.id}>
            {post.title}
            <button onClick={() => { setEditId(post.id); setInput(post.title); }}>Edit</button>
            <button onClick={() => deleteData(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default FetchCRUD;
```

************************************************************************

### Using Axios

### Step 1: Setup and Import Axios

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
```

### Step 2: GET Request Using Axios

```jsx
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(response => setData(response.data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);
```

Here's a React example demonstrating how to perform a GET request using Axios in a functional component with the `useEffect` hook to fetch data:

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AxiosGetExample() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Axios GET request to fetch posts
    axios.get('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(response => {
        setData(response.data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []); // Runs once on component mount

  if (loading) return <p>Loading data...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h2>Fetched Posts (Axios)</h2>
      <ul>
        {data.map(post => (
          <li key={post.id}>
            <strong>{post.title}</strong><br />
            {post.body}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AxiosGetExample;
```

### Explanation:
- `axios.get` fetches the posts from the API.
- On success, the data is stored in `data` state and loading is stopped.
- On error, it stores the error message and stops loading.
- The UI renders loading and error states accordingly and shows the fetched posts.

Make sure you install Axios if not already done by running:

```bash
npm install axios
```

This example shows a clear and effective way to perform a GET request using Axios in React.

### Step 3: POST Request to Add Data

```jsx
  const addData = () => {
    axios.post('https://jsonplaceholder.typicode.com/posts', {
      title: input,
      body: 'Example body',
      userId: 1,
    })
      .then(response => setData([response.data, ...data]))
      .catch(error => console.error('Error adding data:', error));
  };
```
Here is a React example demonstrating how to perform a POST request to add data using Axios inside a functional component with a controlled form:

```jsx
import React, { useState } from 'react';
import axios from 'axios';

function AxiosPostExample() {
  const [title, setTitle] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('https://jsonplaceholder.typicode.com/posts', {
      title: title,
      body: 'Example post body',
      userId: 1,
    })
      .then(response => {
        setResponseData(response.data);
        setError(null);
        setTitle('');
      })
      .catch(error => {
        setError(error.message);
        setResponseData(null);
      });
  };

  return (
    <div>
      <h2>Add a New Post (Axios POST)</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Enter post title"
          required
        />
        <button type="submit">Add Post</button>
      </form>

      {responseData && (
        <div>
          <h3>Post Added Successfully:</h3>
          <p>ID: {responseData.id}</p>
          <p>Title: {responseData.title}</p>
        </div>
      )}

      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
    </div>
  );
}

export default AxiosPostExample;
```

### Explanation:
- A form input controls the `title` state.
- On submit, Axios sends a POST request with the form data.
- On success, it displays the server's response (including the new post ID).
- Errors are caught and shown to the user.
- The input clears after a successful submission.

Remember to install Axios if not installed:

```bash
npm install axios
```

This example clearly demonstrates adding data via a POST request using Axios in React.

### Step 4: PUT Request to Update Data

```jsx
  const updateData = id => {
    axios.put(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      title: input,
      body: 'Updated body',
      userId: 1,
    })
      .then(response => {
        setData(data.map(item => (item.id === id ? response.data : item)));
        setEditId(null);
        setInput('');
      })
      .catch(error => console.error('Error updating data:', error));
  };
```

Here is a React example demonstrating how to perform a PUT request to update data using Axios inside a functional component with controlled inputs:

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AxiosPutExample() {
  const [postId, setPostId] = useState(1);
  const [title, setTitle] = useState('');
  const [updatedData, setUpdatedData] = useState(null);
  const [error, setError] = useState(null);

  // Fetch existing post data to prefill input (optional)
  useEffect(() => {
    axios.get(`https://jsonplaceholder.typicode.com/posts/${postId}`)
      .then(response => setTitle(response.data.title))
      .catch(err => console.error('Error fetching post:', err));
  }, [postId]);

  const handleUpdate = (e) => {
    e.preventDefault();

    axios.put(`https://jsonplaceholder.typicode.com/posts/${postId}`, {
      id: postId,
      title: title,
      body: 'Updated post body',
      userId: 1,
    })
      .then(response => {
        setUpdatedData(response.data);
        setError(null);
      })
      .catch(err => {
        setError(err.message);
        setUpdatedData(null);
      });
  };

  return (
    <div>
      <h2>Update Post (Axios PUT Request)</h2>
      <form onSubmit={handleUpdate}>
        <label>
          Post ID:
          <input
            type="number"
            value={postId}
            onChange={e => setPostId(Number(e.target.value))}
            min="1"
            max="100"
          />
        </label>
        <br />
        <label>
          Title:
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            required
          />
        </label>
        <br />
        <button type="submit">Update Post</button>
      </form>

      {updatedData && (
        <div>
          <h3>Post Updated Successfully:</h3>
          <p>ID: {updatedData.id}</p>
          <p>Title: {updatedData.title}</p>
        </div>
      )}

      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
    </div>
  );
}

export default AxiosPutExample;
```

### Explanation:
- User enters a post ID and new title.
- The existing post title is fetched and set as the input value.
- On form submission, Axios PUT updates the post with new data.
- Success or error messages are displayed accordingly.

This example clearly shows updating data with a PUT request using Axios in React.

### Step 5: DELETE Request to Remove Data

```jsx
  const deleteData = id => {
    axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then(() => setData(data.filter(item => item.id !== id)))
      .catch(error => console.error('Error deleting data:', error));
  };
```


Here is a React example demonstrating how to perform a DELETE request to remove data using Axios inside a functional component. It includes a list of posts with a delete button for each:

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AxiosDeleteExample() {
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState(null);

  // Fetch initial posts
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then(response => setPosts(response.data))
      .catch(err => setError(err.message));
  }, []);

  const deletePost = (id) => {
    axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then(() => {
        setPosts(posts.filter(post => post.id !== id));
        setError(null);
      })
      .catch(err => setError(err.message));
  };

  return (
    <div>
      <h2>Delete Posts (Axios DELETE)</h2>
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <strong>{post.title}</strong>
            <button onClick={() => deletePost(post.id)} style={{ marginLeft: '10px' }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AxiosDeleteExample;
```

### Explanation:
- Posts are fetched initially and shown in a list.
- Each post has a Delete button which triggers an Axios DELETE request.
- On success, the post is removed from the displayed list.
- Errors during deletion are shown to the user.

This example shows an effective way to remove data with a DELETE request in React using Axios.


### Step 6: UI for Axios Interaction (Same as Fetch)

```jsx
  return (
    <div>
      <h2>Axios CRUD Example</h2>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Enter title"
      />
      {editId ? (
        <button onClick={() => updateData(editId)}>Update</button>
      ) : (
        <button onClick={addData}>Add</button>
      )}
      <ul>
        {data.map(post => (
          <li key={post.id}>
            {post.title}
            <button onClick={() => { setEditId(post.id); setInput(post.title); }}>Edit</button>
            <button onClick={() => deleteData(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
```

***

## Summary

- Use **GET** to retrieve data when the component loads (`useEffect`).
- Use **POST** to create new data triggered by a user action.
- Use **PUT** to update existing data.
- Use **DELETE** to remove data.
- Fetch requires manual JSON parsing; Axios simplifies this.
- Axios offers additional features like request cancellation and interceptors.
- UI state is synchronized with API data for a reactive experience.

This step-by-step explanation gives you a clear guide on implementing HTTP methods in React, both with Fetch and Axios, complete with code and theory so you can build fully functional, data-driven React apps.[1][2][3][4][5]

[1](https://www.geeksforgeeks.org/reactjs/axios-in-react-a-guide-for-beginners/)
[2](https://apidog.com/articles/react-fetch-vs-axios/)
[3](https://www.freecodecamp.org/news/how-to-fetch-api-data-in-react-using-axios/)
[4](https://www.smashingmagazine.com/2020/06/rest-api-react-fetch-axios/)
[5](https://www.digitalocean.com/community/tutorials/react-axios-react)