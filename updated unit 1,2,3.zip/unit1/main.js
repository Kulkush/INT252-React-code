// Import named exports
import * as MathOps from './math.js'
import subtract from './math.js';
console.log(MathOps.add(5, 3));       // 8
console.log(MathOps.multiply(5, 3));  // 15
console.log(subtract(5, 3));  // 2
console.log(MathOps.square(4));       // 16
