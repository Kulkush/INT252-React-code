// import Counter from "./Counter"
// import ToggleText from "./ToggleText"
// import LikeButton from "./LikeButton"
// import UserProfile from "./UserProfile"
// import Student from "./Student"
import InputExample from "./InputExample"

function App() {

  return (
    <>
      <InputExample />
      {/* <Student /> */}
      {/* <UserProfile /> */}
      {/* <LikeButton /> */}
      {/* <ToggleText /> */}
      {/* <Counter /> */}
    </>
  )
}

export default App
