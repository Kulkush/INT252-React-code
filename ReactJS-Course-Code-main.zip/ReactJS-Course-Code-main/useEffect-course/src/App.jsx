// import First from './First'
// import Timer from './Timer'
// import WindowSizeTracker from './WindowSizeTracker'
import Users from './Users'

function App() {

  return (
    <>
      <Users />
      {/* <WindowSizeTracker /> */}
      {/* <Timer /> */}
      {/* <First /> */}
    </>
  )
}

export default App
