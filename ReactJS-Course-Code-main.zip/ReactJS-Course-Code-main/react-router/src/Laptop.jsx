export default function Laptop(){
    return (
        <div>
            <h2>Laptop List :</h2>
            <ul>
                <li>Apple Macbook</li>
                <li>Samsung Notebook</li>
                <li>Dell Inspiron</li>
            </ul>
        </div>
    )
}