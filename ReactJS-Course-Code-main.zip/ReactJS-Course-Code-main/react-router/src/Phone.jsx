export default function Phone(){
    return (
        <div>
            <h2>Phone List :</h2>
            <ul>
                <li>Apple iPhone</li>
                <li>Samsung Galaxy</li>
                <li>Google Pixel</li>
            </ul>
        </div>
    )
}