// import WithoutUseMemo from "./WithoutUseMemo"
import Parent from "./Parent"
// import WithUseMemo from "./WithUseMemo"

function App() {

  return (
    <>
      <Parent />
      {/* <WithUseMemo /> */}
      {/* <WithoutUseMemo /> */}
    </>
  )
}

export default App
