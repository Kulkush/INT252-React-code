import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AxiosGetExample() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Axios GET request to fetch posts
        axios.get('https://jsonplaceholder.typicode.com/posts?_limit=5')
            .then(response => {
                setData(response.data);
                setLoading(false);
            })
            .catch(err => {
                setError(err.message);
                setLoading(false);
            });
    }, []); // Runs once on component mount

    if (loading) return <p>Loading data...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <div>
            <h2>Fetched Posts (Axios)</h2>
            <ul>
                {data.map(post => (
                    <li key={post.id}>
                        <strong>{post.title}</strong><br />
                        {post.body}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default AxiosGetExample;