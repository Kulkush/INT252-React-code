import React from 'react'
import FetchDataExample from './FetchDataExample.jsx'
import PostDataExample from './PostDataExample.jsx'
import PutDataExample from './PutDataExample.jsx'
import DeleteDataExample from './DeleteDataExample.jsx'
import AxiosGetExample from './axiosgetexample.jsx'
import AxiosPostExample from './AxiosPostExample.jsx'
import AxiosPutExample from './AxiosPutExample.jsx'
import AxiosDeleteExample from './AxiosDeleteExample.jsx'
// import axios
import { Axios } from 'axios'

function App() {
  return (
    <div>
      <FetchDataExample />
      <PostDataExample />
      <PutDataExample />
      <DeleteDataExample />
      <AxiosGetExample />
      <AxiosPostExample />
      <AxiosPutExample />
      <AxiosDeleteExample />
    </div>
  )
}

export default App
