import React, { useState } from 'react';
import axios from 'axios';

function AxiosPostExample() {
    const [title, setTitle] = useState('');
    const [responseData, setResponseData] = useState(null);
    const [error, setError] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();

        axios.post('https://jsonplaceholder.typicode.com/posts', {
            title: title,
            body: 'Example post body',
            userId: 1,
        })
            .then(response => {
                setResponseData(response.data);
                setError(null);
                setTitle('');
            })
            .catch(error => {
                setError(error.message);
                setResponseData(null);
            });
    };

    return (
        <div>
            <h2>Add a New Post (Axios POST)</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder="Enter post title"
                    required
                />
                <button type="submit">Add Post</button>
            </form>

            {responseData && (
                <div>
                    <h3>Post Added Successfully:</h3>
                    <p>ID: {responseData.id}</p>
                    <p>Title: {responseData.title}</p>
                </div>
            )}

            {error && <p style={{ color: 'red' }}>Error: {error}</p>}
        </div>
    );
}

export default AxiosPostExample;