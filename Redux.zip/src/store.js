import { configureStore } from '@reduxjs/toolkit';
import counterReducer from './feature/counter/counterslice';

const store = configureStore({
    reducer: {
        counter: counterReducer,
    },
});

export default store;

// import { configureStore } from '@reduxjs/toolkit';
// import todosReducer from './feature/todos/todosSlice';

// const store = configureStore({
//     reducer: {
//         todos: todosReducer,
//     },
// });

// export default store;