import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { todoAdded } from './feature/todos/todosSlice';

export default  function TodoInput() {
    const [text, setText] = useState('');
    const dispatch = useDispatch();

    const handleAdd = () => {
        if (text.trim()) {
            dispatch(todoAdded(text));
            setText('');
        }
    };

    return (
        <div>
            <input value={text} onChange={(e) => setText(e.target.value)} />
            <button onClick={handleAdd}>Add Todo</button>
        </div>
    );
}