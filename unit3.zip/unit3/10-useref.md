useRef

Reference hooks are commonly used in React,  to manage references to DOM elements or values that persist across re-renders.

    useRef: It creates a reference that persists for the entire lifecycle of the component. 
    
    In example, inputRef is assigned to the ref attribute of the input field.

    Accessing the DOM Element: When you click the button, the handleFocus function is called. It accesses the current property of the ref to focus the input element.

    Re-rendering: Unlike state, updating the ref (inputRef.current) does not cause a re-render of the component. 
    
    This makes useRef great for managing DOM elements or values that don’t require re-rendering.

\



****************************************************************
The useRef hook in React is commonly used for accessing DOM elements directly and for persisting mutable values across renders without causing a re-render. 

Here are several practical examples:

Focusing an Input Element
This usage allows you to programmatically focus an input when a button is clicked:

jsx
import { useRef } from 'react';

function App() {
  const inputElement = useRef();

  const focusInput = () => {
    inputElement.current.focus();
  };

return (
    <>
      <input type="text" ref={inputElement} />
      <button onClick={focusInput}>Focus Input</button>
    </>
  );
}

This pattern is helpful for improving accessibility or UX, such as focusing inputs after form submission.​

*****************************************************************
Storing and Persisting Mutable Values

useRef can store a value that persists between renders and does not trigger a re-render when updated. For example, tracking button clicks:

jsx
import { useRef } from 'react';

function Counter() {
  const countRef = useRef(0);

  function handleClick() {
    countRef.current += 1;
    alert('You clicked ' + countRef.current + ' times!');
  }

  return <button onClick={handleClick}>Click me!</button>;
}
This is often used for values like timers, intervals, or non-UI state.​


************************************************************************
Tracking Previous Props or State

You can use useRef to remember previous values:

jsx
import { useState, useEffect, useRef } from 'react';

function App() {
  const [inputValue, setInputValue] = useState('');
  const previousValue = useRef('');

  useEffect(() => {
    previousValue.current = inputValue;
  }, [inputValue]);

  return (
    <>
      <input
        value={inputValue}
        onChange={e => setInputValue(e.target.value)}
      />
      <h2>Current: {inputValue}</h2>
      <h2>Previous: {previousValue.current}</h2>
    </>
  );
}
This approach is useful to track the previous state without a re-render.​

**************************************************************************
Manipulating DOM Elements (Textarea Example)

Direct DOM manipulation (like setting text and focusing a textarea):

jsx
import { useRef } from 'react';

function Example() {
  const textareaRef = useRef(null);

  function handleClick() {
    textareaRef.current.value = "The quick brown fox jumps over the lazy dog";
    textareaRef.current.focus();
  }

  return (
    <>
      <button onClick={handleClick}>ACTION</button>
      <textarea ref={textareaRef} />
    </>
  );
}
This pattern is useful for scenarios needing direct DOM updates outside of React's state-based flow